package com.fannie;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HlloWorld extends HttpServlet {
	private static final long serialVersionUID = 1L;


	
	public void init(ServletConfig config) throws ServletException {
		
		
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>INIT>>>>>>>>>");
	}

	public void destroy() {
		
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>INITDESTROY>>>>>>>>>>>>>>");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
	PrintWriter out =response.getWriter();
	
	out.println("<html>'");

	out.println("<body>");

	out.println("<h3>Welcome to Servlets </h3>");

	out.println("</body>");

	out.println("</html");

	 

	out.close();

		
	}

}
