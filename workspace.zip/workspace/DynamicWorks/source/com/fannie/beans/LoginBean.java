package com.fannie.beans;

public class LoginBean {

}
