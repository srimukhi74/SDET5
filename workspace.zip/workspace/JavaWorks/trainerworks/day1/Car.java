package day1;

public class Car extends Vehicle {

	public Car() {
		System.out.println("Car Constructed..");
	}

	public void streeing() {
		System.out.println("Car has streering");
	}

	public void feulCapacity(int capacity) {
		System.out.println("Car Capacity " + capacity);
	}
}
