 package com.fannie;

public class Vehicle {

	public void move() {
		System.out.println("All vehicles move... ");
	}

	public void brake() {
		System.out.println("Vechile applied Break");
	}

}
