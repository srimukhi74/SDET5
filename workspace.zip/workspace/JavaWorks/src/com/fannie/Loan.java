package com.fannie;

// resuable component
public class Loan {
private int lid;
private double  loanAmount;
private double rateOfInterest;
private String borrowerName;
public int getLid() {
	return lid;
}
public double getLoanAmount() {
	return loanAmount;
}
public void setLoanAmount(double loanAmount) {
	this.loanAmount = loanAmount;
}
public double getRateOfInterest() {
	return rateOfInterest;
}
public void setRateOfInterest(double rateOfInterest) {
	this.rateOfInterest = rateOfInterest;
}
public String getBorrowerName() {
	return borrowerName;
}
public void setBorrowerName(String borrowerName) {
	this.borrowerName = borrowerName;
}
public void setLid(int lid) {
	this.lid = lid;
}
}
