package com.fannie;

public abstract class Figure {
	public abstract void area();
	public void draw(){}
}

class Rect extends Figure {
	int len;
	int bre;

	Rect(int len, int bre) {
		this.len = len;
		this.bre = bre;
	}

	@Override
	public void area() {
		System.out.println("Are is " + (len * bre));
	}

	@Override
	public void draw() {
		System.out.println("to Draw Rectangle i need a ruler ....");
		super.draw();
	}
	
	
	
}

class Sqr extends Figure {
	int len;

	Sqr(int len) {
		this.len = len;
	}

	@Override
	public void area() {
		System.out.println(" Area of Sqr " + (len * len));

	}
}
