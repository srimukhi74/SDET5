package com.fannie;

public class Carjava extends Vehicle {
	public Carjava() {
		System.out.println("Car Constructed...");
	}

	public void Streeing() {
		System.out.println("Car has Steering");
	}

	public void feualCapacity(int capacity) {
		System.out.println("car capacity" + capacity);
	}
}
