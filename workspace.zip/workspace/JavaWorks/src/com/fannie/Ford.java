package com.fannie;

public class Ford extends Carjava {
	public Ford(){
		System.out.println( "Ford Constructed ");
	}
public void abs(){
	System.out.println("ford has abs  ");
}
}
