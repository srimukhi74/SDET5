package com.fannie;

import day1.Car;

public class Audi extends Car{
	
	public Audi() {
		System.out.println("Audi constructed...");
	}
	
	public void view(){
		System.out.println("audi has rear view...");
	}
}