package com.fannie;

public class CarBL {
	public void showCar(Carjava []  cars){
		for (Carjava temp : cars);
		System.out.println("...............");
	
		
		
	}

}
