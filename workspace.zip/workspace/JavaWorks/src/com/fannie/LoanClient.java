package com.fannie;

public class LoanClient {
	public static void main(String[]args){
		Loan loanScott;
loanScott =new Loan();


loanScott.setLid(101);
loanScott.setBorrowerName("Scott");
loanScott.setLoanAmount(4444);
loanScott.setRateOfInterest(7);


System.out.println("Loan Id " + loanScott.getLid());
System.out.println("Loan Borrower Name" +loanScott.getBorrowerName());
System.out.println("Rate of Interst" + loanScott.getLoanAmount());



}
}
