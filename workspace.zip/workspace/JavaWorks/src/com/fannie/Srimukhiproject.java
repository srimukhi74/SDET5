package com.fannie;

public class Srimukhiproject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double x, y, answer;
		x =70;
		y =15;
	answer =x/ y;
		
System.out.println( answer);
	}
}

	