package com.fannieday3;

import java.util.TreeSet;

import java.util.Set;

public class SetEx3 {
	public static void main(String[] args) {
		Set<String> set = new TreeSet<String>();
		
		set.add("Shashikanth");
		set.add("Sujakumar");
		set.add("Deepti");
		set.add("Kawsar");
		System.out.println(set);
	}
}
