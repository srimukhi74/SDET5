package com.fannieday3;

public class ThreadEx1 {
	
	public static void main(String[] args) {
		System.out.println("thread name" + Thread.currentThread().getName());
		
		System.out.println("Thread Priority " + Thread.currentThread().getPriority());
	}
	
	

}
