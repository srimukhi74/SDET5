package com.fannieday3;

import java.util.Set;
import java.util.TreeSet;

public class SetEx4 {
	public static void main(String[] args) {

		Set<Device> set = new TreeSet<Device>();
		set.add(new Device(101, "Laptop", 2000));
		set.add(new Device(222, "Mobile", 1200));
		set.add(new Device(121, "Projector", 3000));
		set.add(new Device(78, "AC", 4545));
		set.add(new Device(78, "AC", 4545));
		set.add(new Device(78, "AC", 4545));
				
		set.forEach(System.out :: println);
		
		
		
	}
}
