package com.fannieday3;

import java.util.Comparator;

public class DeviceSort implements Comparator<Device> {
	
	@Override
	public int compare(Device o1, Device o2){
		return o2.getdName().compareTo(o1.getdName());
		
	
	
public static Comparator<Device> sortDescOnName(){
	return new Comparator<Device>(){

		@Override
		public int compare(Device arg0, Device arg1) {
			// TODO Auto-generated method stub
			return 0;
		}
		
		
	

}
