package day4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.fannieday2.Account;

public class MapEx1 {
	
	public static void main(String[] args) {
	Map<String, Integer> accounts =new HashMap<String, Integer>();
	
	accounts.put("abdul", 10000);
	accounts.put("suresh", 20000);
	accounts.put("peter", 50000);
	
	System.out.println("Abdul Balance  " + accounts.get("abdul"));
	System.out.println("Suresh Balance  " + accounts.get("suresh"));
	System.out.println("Peter Balance  " + accounts.get("peter"));
	

	Iterator itr =accounts.entrySet().iterator();
	
	while(itr.hasNext()){
		
		
		Map.Entry<String,Integer> temp =(Entry<String, Integer>) itr.next();
		System.out.println("Key  " + temp.getKey()
		+"' value " + temp.getValue());
		
	}
	
	
		
		
	}
	
	
	

}
