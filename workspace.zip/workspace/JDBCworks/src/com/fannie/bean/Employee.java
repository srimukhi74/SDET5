package com.fannie.bean;

public class Employee {
	
	
	private int Employee;
	private String empName;
	private double empSal;
	private String email;
	public int getEmployee() {
		return Employee;
	}
	public void setEmployee(int employee) {
		Employee = employee;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Employee [Employee=" + Employee + ", empName=" + empName + ", empSal=" + empSal + ", email=" + email
				+ "]";
		
		
		public employee(){}
	}
	public Employee(int employee, String empName, double empSal, String email) {
		super();
		Employee = employee;
		this.empName = empName;
		this.empSal = empSal;
		this.email = email;
	}
	

	

}
