

public class Road {
	public static void main(String [] args){
		Vehicles cars [] = new Vehicles[3];
		cars[0] = new Car(4, "red", "Honda accord");
		cars[1] = new Truck(4, "blue", "ford");
		cars[2] = new Bus(8, "black", "Greyhound");
		
		for (Vehicles temp : cars);
		System.out.println("...............");
	}
}
