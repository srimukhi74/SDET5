
public class Car extends Vehicles {

		public Car(int wheelsIn, String colorIn, String modelIn){
			super(wheelsIn, colorIn, modelIn);
			System.out.println("Car Constructed");
		}
		public void Steering(){
			System.out.println("Car can steer");
		}
		public void fuelStorage(int capacity){
			System.out.println("Max Capacity is: " + capacity);
		}
}
