
public class Truck extends Vehicles{
	
	public Truck(int wheelsIn, String colorIn, String modelIn){
		super(wheelsIn, colorIn, modelIn);
		System.out.println("Truck Constructed");
	}
	public void numOfAxles(int axles){
		System.out.println("Truck has " + axles + " axles");
	}
	public boolean isTwoDoor(int doors){
		if(doors == 2){
			return true;
		}else{
			return false;
		}
	}
}
