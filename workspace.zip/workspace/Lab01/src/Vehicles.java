
public class Vehicles {
	
	
	public Vehicles(int wheelsIn, String colorIn, String modelIn){
		int wheels = wheelsIn;
		String Color = colorIn;
		String Model = modelIn;
	}
	public void move(){
		System.out.println("All cars moved");
	}
	public void brake(){
		System.out.println("All cars have braked");
	}

}
