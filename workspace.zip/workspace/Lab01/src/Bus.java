
public class Bus extends Vehicles{

	public Bus(int wheelsIn, String colorIn, String modelIn){
		super(wheelsIn, colorIn, modelIn);
		System.out.println("Bus Constructed");
	}
	
}
