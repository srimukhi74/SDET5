package com.fannie.step;

import cucumber.api.java.en.And;
import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreditScoreStep {
	// step defn

	@Given("Employee has a credit score")
	public void employee_has_a_credit_score() {

		System.out.println("employee has a credit score");
	}

	@And("according to bank standard")
	public void according_to_bank_standard() {
		System.out.println("according to bank standard");

	}
	// this will be generic method
	// this will take one type of work or anything

	@When("Customer has a ([a-zA-Z]{1,}) time work")
	public void Customer_has_a_full_time_work(String workTime) {
		System.out.println("Customer has a  "+workTime+"time work");

	}

	@And("in govt office")
	public void in_govt_office() {
		System.out.println("in govt office");
	}

	@Then("^Sanction loan$")
	public void Sanction_loan() {
		System.out.println("Sanction loan");
	}

	@But("should repay within 5 years")
	public void should_repay_within_5_years() {
		System.out.println("should repay within 5 years");

	}

	@And("in private office")
	public void in_private_office() {
		System.out.println("in private office");
	}
}
