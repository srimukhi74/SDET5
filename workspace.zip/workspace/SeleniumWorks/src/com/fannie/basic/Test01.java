package com.fannie.basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test01 {

	public static void main(String[] args) {
		// load The Driver
		WebDriver driver = null;
		// System.setProperty("webdriver.gecko.driver",
		// "C:\\softwares\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		// driver= new FirefoxDriver();

		System.setProperty("webdriver.chrome.driver", "C:\\softwares\\chromedriver_win32\\chromedriver.exe");
		// Open the browser for the driver

		driver = new ChromeDriver();
		String baseUrl = "http://google.com";
		driver.get(baseUrl);
		// do the task
		System.out.println("Title   " + driver.getTitle());

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// close the browser
		
		

	}

}
