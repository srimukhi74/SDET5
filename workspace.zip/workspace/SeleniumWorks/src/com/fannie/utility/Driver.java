package com.fannie.utility;

public interface Driver {

String CHROME ="webdriver.chrome.driver";

String FIREFOX ="webdriver.firefox.driver";	 

//PATH
String CHROME_PATH="C:\\softwares\\chromedriver_win32\\chromedriver.exe";
String FIREFOX_PATH = "C:\\softwares\\geckodriver-v0.16.1-win64\\geckodriver.exe";



}