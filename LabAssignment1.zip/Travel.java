package com.LabAssignment1;

// Interface Travel
public interface Travel {
	public void move ();
	public void brake ();
}
