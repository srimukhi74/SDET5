package com.LabAssignment1;

import com.LabAssignment1.Vehicle.Bus;
import com.LabAssignment1.Vehicle.Car;
import com.LabAssignment1.Vehicle.Truck;


// Road Class
public class Road {
	
	public static void main(String[] args) {
		
		// Generic messages about vehicles on the Road from Interface and Class
		System.out.println("------------------------------------------------------------");
		Vehicle v = new Vehicle();
		v.move();
		v.brake();
		v.color(null);
		v.noOfWheels(0);
		v.model(null);
		
		
		// Object Car displaying the appropriate messages
		// including appropriate values from the subclass
		Car car = v.new Car();
		System.out.println("------------------------------------------------------------");
		car.Jaguar();
		car.move();
		car.brake();
		car.cls();
		car.color("Satin Blue");
		car.noOfWheels(4);
		car.model("F - TYPE SVR");
		System.out.println("------------------------------------------------------------");
		
		// Object Truck displaying the appropriate messages
		// including appropriate values from the subclass
		Truck truck = v.new Truck();		
		System.out.println("------------------------------------------------------------");
		truck.Freightliner();
		truck.move();
		truck.brake();
		truck.ams();
		truck.color("White");
		truck.noOfWheels(18);
		truck.model("Cascadia Evolution");
		System.out.println("------------------------------------------------------------");
		
		// Object Bus displaying the appropriate messages
		// including appropriate values from the subclass
		Bus bus = v.new Bus();
		System.out.println("------------------------------------------------------------");
		bus.Greyhound();
		bus.move();
		bus.brake();
		bus.luggageRacks();
		bus.color("Silver Grey");
		bus.noOfWheels(6);
		bus.model("Prevost X3-45");
		System.out.println("------------------------------------------------------------");
		
		
		}
				

}

