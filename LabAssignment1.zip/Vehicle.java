package com.LabAssignment1;

// Vehicle class implements Interface Travel
public class Vehicle implements Travel {

	// Methods move() and brake() from Interface Travel overridden
	@Override
	public void move() {
		System.out.println("Vehicles on the road are moving..... ");
		
	}

	@Override
	public void brake() {
		System.out.println("Vehicles on the road stopped because of brakes applied..... ");
		
	}

	// Initialize variables color, no of wheels and model
	public void color(String myColor) {
		System.out.println("Vehicles on the road have different colors.... ");
		return;
	}
	
	public void noOfWheels(int myWheels) {
		System.out.println("Vehicles on the road have different number of wheels.... ");
		return;
	}
	
	public void model(String myModel) {
		System.out.println("Vehicles on the road are of different models...... ");
		return;
	}
	
// Subclass Car
public class Car extends Vehicle{

	//Specific method to subclass Car
	public void Jaguar() {
		System.out.println("Jaguar is on the Road ");
	}
	
	//Specific method to subclass Car
	public void cls(){
		System.out.println("Jaguar has 'Configurable Lighting System' ");
	}
	
	@Override
	public void move(){
		System.out.println("Jaguar is moving forward when accelerated ");
	}
	
	@Override
	public void brake() {
		System.out.println("Jaguar stopped when the brakes are applied ");
	}
	
	@Override
	public void color(String myColor) {
		System.out.println("Jaguar is " + "'" + myColor + "'" + " in color ");
		return;
	}
	
	public void noOfWheels(int myWheels) {
		System.out.println("Jaguar has " + "'" + myWheels + "'" + " wheels ");
		return;
	}
	
	@Override
	public void model(String myModel) {
		System.out.println("Jaguar model is " + "'" + myModel + "'");
		return;
	}
	
	

}

// Subclass Truck
public class Truck extends Vehicle{
	
	//Specific method to subclass Truck
	public void Freightliner() {
		System.out.println("Freightliner is on the Road ");
	}
	
	//Specific method to subclass Truck
	public void ams(){
		System.out.println("Freightliner has 'Automated Manual Transmission' ");
	}
	
		@Override
		public void move() {
			System.out.println("Freightliner is moving forward when accelerated ");
			
		}

		@Override
		public void brake() {
			System.out.println("Freightliner stopped when the brakes are applied ");
			
		}

		@Override
		public void color(String myColor) {
			System.out.println("Freightliner is " + "'" + myColor + "'" + " in color ");
			return;
		}

		@Override
		public void noOfWheels(int myWheels) {
			System.out.println("Freightliner has " + "'" + myWheels + "'" + " wheels ");
			return;
		}

		@Override
		public void model(String myModel) {
			System.out.println("Freightliner model is " + "'" + myModel + "'");
		}
		
		

}

// Subclass Vehicle
public class Bus extends Vehicle{
	
	//Specific method to subclass Bus
	public void Greyhound() {
		System.out.println("Greyhound is on the Road ");
	}
	
	//Specific method to subclass Bus
	public void luggageRacks(){
		System.out.println("Greyhound has 'Luggage Racks' ");
	}
	
		@Override
		public void move() {
			System.out.println("Greyhound is moving forward when accelerated ");
			
		}

		@Override
		public void brake() {
			System.out.println("Greyhound stopped when the brakes are applied ");
			
		}

		@Override
		public void color(String myColor) {
			System.out.println("Greyhound is " + "'" + myColor + "'" + " in color ");
			return;
		}

		@Override
		public void noOfWheels(int myWheels) {
			System.out.println("Greyhound has " + "'" + myWheels + "'" + " wheels ");
			return;
		}

		@Override
		public void model(String myModel) {
			System.out.println("Greyhound model is " + "'" + myModel + "'");
			return;
		}
		
	
}


}
