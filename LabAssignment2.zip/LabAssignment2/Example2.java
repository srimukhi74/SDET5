package com.LabAssignment2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

// LAB ASSIGNMENT 2
// Synonyms shown for words input using HashMap

public class Example2 {
	
	public static class Ontology {
	    HashMap<String,ArrayList<String>> synonyms;
	    
	    public Ontology() {
	        synonyms = new HashMap<>();
	        
	    }
	    
	    private void addToWordList(HashMap<String,ArrayList<String>> wordListMap, String word, String wordToAdd) {
	        ArrayList<String> wordList;

	        if ((wordList=wordListMap.get(word)) == null) {
	            wordList = new ArrayList<>();
	        }
	        wordList.add(wordToAdd);
	        wordListMap.put(word, wordList);
	    }
	    
	    private String [] getWordFromWordList(HashMap<String,ArrayList<String>> wordListMap, String word) {
	        ArrayList<String> wordList;

	        if ((wordList=wordListMap.get(word)) == null) {
	            return null;
	        }
	        return wordList.toArray(new String [1]);
	    }
	    
	    public void addSynonym(String word, String synonym) {
	        addToWordList(synonyms, word, synonym);
	    }
	    
	    public String [] getSynonyms(String word) {
	        return getWordFromWordList(synonyms, word);
	    }
	    
	    // Read the data from the flat file(.txt extension) into an Array List
	    public static void main(String args[]) throws IOException {
	    	
	    	BufferedReader in = new BufferedReader(new FileReader("C:/workspace/JavaWorks/src/com/LabAssignment2/Synonyms.txt"));
			String str;
			
			List<String> valSetOne = new ArrayList<String>();
			while((str = in.readLine()) != null){
				valSetOne.add(str);
				
			}
			
			valSetOne.toArray(new String[0]);
			
			List<String> valSetTwo = new ArrayList<String>();
			while((str = in.readLine()) != null){
				valSetTwo.add(str);
			}
			
			valSetTwo.toArray(new String[1]);
			
			List<String> valSetThree = new ArrayList<String>();
			while((str = in.readLine()) != null){
				valSetThree.add(str);
			}
			
			valSetThree.toArray(new String[2]);
			
	        Ontology o = new Ontology();
	        o.addSynonym("Hello", "hi");
	        o.addSynonym("Hello", "howdy");
	        o.addSynonym("Hello", "hiya");
	        o.addSynonym("Bye", "adios");
	        o.addSynonym("Bye", "cheerio");
	        o.addSynonym("Bye", "goodbye");
	        o.addSynonym("Good Morning", "bonjour");
	        o.addSynonym("Good Morning", "subhodayam");
	        o.addSynonym("Good Morning", "greetings");
	        
	        
	        Scanner scan = new Scanner(System.in);
	        
	        String word1 = "";
	        String synonym1 = "";
	        String synonym2 = "";
	        String synonym3 = "";
      
	        int option;
	        do{	   
	        	// User selects an option
	        	System.out.println("---------------------------------------");
	        	String menu = "Please select an option: "
	        		+ "\n 1. Show Synonym"
	                + "\n 2. Add Synonym"          
	                + "\n 3. To Exit";
	        	System.out.println(menu);
	        	
	        	option = scan.nextInt();

	        	 switch (option)
	        	    {
	        	 		// Option 1: Show Synonym
	        	 		// Enter the Word to show Synonyms
	        	        case 1:
	        	        	System.out.println("-------------------------------------");
	        	        	System.out.println("Please enter the Word: ");
	        	        	
	        	        	Scanner input = new Scanner(System.in);
	    	        	    String answer = input.nextLine();
	        	        	
	        	        	if ("Hello".equals(answer)){
	        	        		for (String word: o.getSynonyms("Hello")) {
	        	        			System.out.println("Word entered is Hello");
	        			            System.out.println("One Synonym is: " + word);
	        			            System.out.println("-------------------------------------");
	        			        }
	        	        		
	        	        	} else if ("Bye".equals(answer)){
	        	        		for (String word: o.getSynonyms("Bye")) {
	        	        			System.out.println("Word entered is Bye");
	        			            System.out.println("One Synonym is: " + word);
	        			            System.out.println("-------------------------------------");
	        			        }
	        	        		
	        	        	} else if ("Good Morning".equals(answer)){
	        	        		for (String word: o.getSynonyms("Good Morning")) {
	        	        			System.out.println("Word entered is Good Morning");
	        			            System.out.println("One Synonym is: " + word);
	        			            System.out.println("-------------------------------------");
	        			        }
	        	        		
	        	        	} else{      	
	        	        		System.out.println("Word not found");
	        	        		System.out.println("-------------------------------------");
	        	        	}
	        	        	break;
			   
	        	        // Option 2: Add Synonym
	        	        // Add Word and Synonyms
	        	        case 2:	        	        	
	        	        	Scanner input1 = new Scanner(System.in);

	        	        	System.out.println("Please enter a word to add synonyms for");
	        	        	word1 = input1.nextLine();
	        	        	System.out.println("Please enter the synonym for the word entered");
	        	        	synonym1 = input1.nextLine();
	        	        	System.out.println("Please enter another synonym for the word entered");
	        	        	synonym2 = input1.nextLine();
	        	        	System.out.println("Please enter another synonym for the word entered");
	        	        	synonym3 = input1.nextLine();
	        	        	
	        	        	o.getSynonyms(word1);
	        		        o.addSynonym(word1, synonym1);
	        	        	o.addSynonym(word1, synonym2);
	        	        	o.addSynonym(word1, synonym3);
	        	        	System.out.println("Word entered is " + word1);
    			            System.out.println("Synonym entered is : " + synonym1);
    			            System.out.println("Synonym entered is : " + synonym2);
    			            System.out.println("Synonym entered is : " + synonym3);
    			            System.out.println("-------------------------------------");
	        	        
	        	        	break;
	        	        	
	        	        // Option 3: Exit
	        	        case 3:
	        	        	System.out.println("No option selected, ending the program");
	        	        	break;

			    }
	        	 
	        }while(option > 0 && option < 3);
			
	    }
}
		
}


	

