package com.LabAssignment2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


// To obtain synonyms in a List from a flat file stored in .txt format
public class SynonymList {
	public static void main(String[] args) {
		File f = new File("C:/workspace/JavaWorks/src/com/LabAssignment2/Synonyms.txt");
			try{
				List<String> lines = get_list_from_file(f);
				for(int x = 0; x < lines.size(); x++){
					System.out.println(lines.get(x));
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			System.out.println("Done");
		
		
	}
	

public static List<String> get_list_from_file(File f) 
		throws FileNotFoundException {
		Scanner s;
		List<String> list = new ArrayList<String>();
		s = new Scanner(f);
		while (s.hasNext()) {
			list.add(s.next());
		}
		s.close();
		return list;
	}


			
}




